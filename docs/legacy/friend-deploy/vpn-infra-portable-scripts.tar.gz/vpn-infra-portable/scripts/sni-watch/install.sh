#!/bin/bash
# Portable installer. Run on the Xray entry node (where access.log has per-user email).
# Usage:
#   AUTH_USER=watch AUTH_PASS='...' ./install.sh
# Optional: ACCESS_LOG=... LISTEN=127.0.0.1:8787
set -euo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"
LIB=/usr/local/lib/sni-watch
ETC=/etc/sni-watch
VAR=/var/lib/sni-watch
ACCESS_LOG="${ACCESS_LOG:-/var/log/xray/access.log}"
LISTEN="${LISTEN:-127.0.0.1:8787}"
AUTH_USER="${AUTH_USER:-watch}"

if [[ ! -f "$DIR/app.py" ]]; then
  echo "app.py missing next to install.sh" >&2
  exit 2
fi

install -d -m 755 "$LIB" "$ETC" "$VAR"
install -m 644 "$DIR/app.py" "$DIR/adult-domains.txt" "$LIB/"
install -m 644 "$DIR/sni-watch.service" /etc/systemd/system/sni-watch.service

if [[ ! -f "$ETC/extra-domains.txt" ]]; then
  cat > "$ETC/extra-domains.txt" << 'EOF'
# Extra hostnames, one per line (suffix match).
EOF
  chmod 644 "$ETC/extra-domains.txt"
fi

if [[ -z "${AUTH_PASS:-}" && -f "$ETC/admin.pass" ]]; then
  AUTH_PASS="$(cat "$ETC/admin.pass")"
fi
if [[ -z "${AUTH_PASS:-}" ]]; then
  AUTH_PASS="$(python3 -c 'import secrets; print(secrets.token_urlsafe(18))')"
fi

export SNI_WATCH_LISTEN="$LISTEN"
export SNI_WATCH_ACCESS_LOG="$ACCESS_LOG"
export SNI_WATCH_DB="$VAR/watch.db"
export SNI_WATCH_DOMAINS="$LIB/adult-domains.txt"
export SNI_WATCH_EXTRA="$ETC/extra-domains.txt"
export SNI_WATCH_USER="$AUTH_USER"
export SNI_WATCH_PASS="$AUTH_PASS"
export SNI_WATCH_CFG="$ETC/config.env"

python3 << 'PY'
import hashlib, os, secrets
from pathlib import Path
password = os.environ["SNI_WATCH_PASS"]
salt = secrets.token_bytes(16)
iters = 200_000
dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, iters)
auth_hash = "pbkdf2_sha256$%d$%s$%s" % (iters, salt.hex(), dk.hex())
secret = secrets.token_hex(32)
text = "\n".join([
    "LISTEN=" + os.environ["SNI_WATCH_LISTEN"],
    "ACCESS_LOG=" + os.environ["SNI_WATCH_ACCESS_LOG"],
    "DB_PATH=" + os.environ["SNI_WATCH_DB"],
    "DOMAINS_FILE=" + os.environ["SNI_WATCH_DOMAINS"],
    "EXTRA_DOMAINS=" + os.environ["SNI_WATCH_EXTRA"],
    "AUTH_USER=" + os.environ["SNI_WATCH_USER"],
    "AUTH_HASH=" + auth_hash,
    "SESSION_SECRET=" + secret,
    "COALESCE_SEC=120",
    "COOKIE_NAME=sniwatch",
    "USERMAP=/etc/sni-watch/usermap.json",
    "",
])
path = Path(os.environ["SNI_WATCH_CFG"])
path.write_text(text)
path.chmod(0o600)
PY

umask 077
printf '%s\n' "$AUTH_USER" > "$ETC/admin.user"
printf '%s\n' "$AUTH_PASS" > "$ETC/admin.pass"
chmod 600 "$ETC/admin.user" "$ETC/admin.pass"

systemctl daemon-reload
systemctl enable --now sni-watch.service
systemctl restart sni-watch.service

echo "installed listen=${LISTEN} user=${AUTH_USER} passfile=${ETC}/admin.pass"
