#!/usr/bin/env python3
"""Monitor 3: traffic quota.

Exit: rolling 24h vs 2TB fair-use (netcup throttles to 200 Mbit/s). Not monthly.
Iran: monthly RX-only 1.5TB, reset day 26.
"""
from __future__ import annotations

import datetime as dt
import json
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from lib import (  # noqa: E402
    cfg,
    days_left_in_month,
    evaluate,
    fmt_bytes,
    iface_counters,
    load_state,
    role,
    save_state,
    send,
)
from netcup_oauth import rolling_24h  # noqa: E402

IRAN_LEVELS = (70, 85, 95)
EXIT_ROLLING_LEVELS = (60, 80, 95)


def vnstat_rx_since(reset_day: int) -> tuple[int | None, str]:
    try:
        raw = subprocess.check_output(["vnstat", "--json", "d"], text=True, timeout=10)
        doc = json.loads(raw)
    except Exception:
        return proc_rx_estimate(reset_day), "proc"

    today = dt.date.today()
    day = max(1, min(28, reset_day))
    if today.day >= day:
        start = dt.date(today.year, today.month, day)
    else:
        if today.month == 1:
            start = dt.date(today.year - 1, 12, day)
        else:
            start = dt.date(today.year, today.month - 1, day)

    total = 0
    found = False
    for iface in doc.get("interfaces") or []:
        days = ((iface.get("traffic") or {}).get("day")) or []
        for row in days:
            y = int(row.get("date", {}).get("year") or 0)
            m = int(row.get("date", {}).get("month") or 0)
            d = int(row.get("date", {}).get("day") or 0)
            try:
                when = dt.date(y, m, d)
            except ValueError:
                continue
            if when >= start:
                total += int(row.get("rx") or 0)
                found = True
    if found:
        return total, "vnstat_rx"
    return proc_rx_estimate(reset_day), "proc"


def proc_rx_estimate(reset_day: int) -> int | None:
    c = cfg()
    iface = c["IFACE"]
    p = Path(f"/sys/class/net/{iface}/statistics/rx_bytes")
    if not p.exists():
        return None
    now_rx = int(p.read_text().strip())
    st = load_state()
    snap = st.get("quota_rx_snap") or {}
    cycle = f"{dt.date.today().year}-{dt.date.today().month:02d}-{int(reset_day):02d}"
    if snap.get("cycle") != cycle:
        st["quota_rx_snap"] = {"cycle": cycle, "rx": now_rx}
        save_state(st)
        return 0
    return max(0, now_rx - int(snap.get("rx") or 0))


def maybe_iran_reminder(c: dict) -> None:
    reset_day = int(c.get("IRAN_QUOTA_RESET_DAY") or 26)
    now = dt.datetime.now()
    if now.day != reset_day or now.hour < 8 or now.hour > 11:
        return
    st = load_state()
    stamp = f"quota_reminder_IRAN_{now.year}_{now.month:02d}"
    if st.get(stamp):
        return
    st[stamp] = True
    save_state(st)
    send(
        "quota",
        "info",
        "یادآوری ماهانه سهمیه ترافیک ایران",
        [
            "فقط RX/دانلود، سقف ۱.۵ ترابایت.",
            f"روز ریست IRAN_QUOTA_RESET_DAY={reset_day}",
            "با پنل ارائه‌دهنده چک کنید.",
        ],
    )


def fire_iran_levels(used: int, quota: int, source: str, extra: list[str], reset_day: int) -> None:
    if quota <= 0:
        return
    pct = used / quota * 100
    left = days_left_in_month(reset_day)
    st = load_state()
    cycle = dt.date.today().strftime("%Y-%m")
    rec = st.get("quota_levels") or {}
    if rec.get("cycle") != cycle:
        rec = {"cycle": cycle, "sent": []}
    sent = list(rec.get("sent") or [])
    details = [
        f"used={fmt_bytes(used)}  quota={fmt_bytes(quota)}  {pct:.1f}%",
        f"source={source}",
        f"days_left_in_cycle≈{left}",
        *extra,
    ]
    for lv in IRAN_LEVELS:
        if pct >= lv and lv not in sent:
            sent.append(lv)
            rec["sent"] = sent
            rec["cycle"] = cycle
            st["quota_levels"] = rec
            save_state(st)
            send("quota", "breach", f"سهمیه ترافیک ایران به {lv}% رسید", details)


def current_band(pct: float) -> int:
    if pct >= 95:
        return 95
    if pct >= 80:
        return 80
    if pct >= 60:
        return 60
    return 0


def local_mbps() -> float:
    """Iface TX+RX bits/s since last quota run."""
    import time

    c = cfg()
    iface = c["IFACE"]
    cur = iface_counters(iface)
    now = time.time()
    st = load_state()
    prev = st.get("_exit_bw") or {}
    st["_exit_bw"] = {"ts": now, "rx": cur["rx_bytes"], "tx": cur["tx_bytes"]}
    save_state(st)
    if not prev.get("ts") or now <= float(prev["ts"]) + 1:
        return 0.0
    dt = now - float(prev["ts"])
    bps = (cur["rx_bytes"] - int(prev.get("rx") or 0) + cur["tx_bytes"] - int(prev.get("tx") or 0)) / dt
    return max(0.0, bps * 8 / 1_000_000)


def exit_rolling() -> None:
    c = cfg()
    limit = int(c.get("EXIT_ROLLING_LIMIT_BYTES") or 2_000_000_000_000)
    throttle_mbit = float(c.get("EXIT_THROTTLE_MBIT") or 200)
    vname = c.get("NETCUP_VSERVER_NAME") or "v2202608400527502404"
    extra = [
        "آلمان سقف ماهانه ندارد؛ آستانه غلتان ۲۴ساعته ۲ ترابایت است.",
        "بالای ۲TB/24h نت‌کاپ لینک را تا حدود ۲۰۰ مگابیت محدود می‌کند.",
        f"VSERVER_NAME={vname} id از API",
    ]
    try:
        info = rolling_24h(vname)
        used = int(info["total_bytes"])
        source = info["source"]
        extra.append(
            f"API 24h IN={fmt_bytes(info['in_bytes'])} OUT={fmt_bytes(info['out_bytes'])} "
            f"buckets={info['buckets']} recent≈{info['recent_mbps']:.1f} Mbit/s"
        )
        extra.append("SCP فیلد throttle جدا ندارد (BandwidthClass در اسکیما هست ولی روی GET server نیست).")
        recent = float(info["recent_mbps"] or 0)
    except SystemExit as e:
        send("quota", "info", "نتوانستم متریک ۲۴ساعته SCP را بخوانم", extra + [str(e)])
        return
    except Exception as e:
        send("quota", "info", "خطای SCP REST برای متریک شبکه", extra + [type(e).__name__])
        return

    pct = (used / limit * 100) if limit else 0
    loc = local_mbps()
    extra.append(f"iface_sample={loc:.1f} Mbit/s  limit={fmt_bytes(limit)}  used_24h={fmt_bytes(used)} ({pct:.2f}%)")

    st = load_state()
    rec = st.get("exit_rolling") or {}
    prev_band = int(rec.get("band") or 0)
    band = current_band(pct)
    rec["band"] = band
    rec["used"] = used
    rec["pct"] = pct
    st["exit_rolling"] = rec
    save_state(st)

    details = extra[:]
    if band > prev_band and band in EXIT_ROLLING_LEVELS:
        send("quota", "breach", f"ترافیک غلتان ۲۴ساعته به {band}% از ۲TB رسید", details)
    elif prev_band >= 60 and band < prev_band:
        send("quota", "recovery", f"ترافیک غلتان ۲۴ساعته برگشت به {band or 'زیر ۶۰'}%", details)

    # Throttle: 2TB window full, or near-full with ~200 Mbit ceiling on API 10-min avg or iface.
    near_cap = 150 <= max(recent, loc) <= (throttle_mbit + 30)
    high_window = used >= limit or pct >= 95
    throttled = bool(used >= limit or (high_window and near_cap))
    ev = evaluate("exit_throttle", throttled, sustain=0, cooldown=int(c.get("COOLDOWN_SEC") or 1800))
    if ev in ("breach", "rebreach"):
        send(
            "quota",
            "breach",
            f"احتمال محدودیت نت‌کاپ (~{throttle_mbit:.0f} Mbit/s) — پنجره ۲۴ساعته {pct:.1f}% از ۲TB",
            details,
        )
    elif ev == "recovery":
        send("quota", "recovery", "محدودیت ۲۰۰ مگابیت ظاهراً برداشته شد", details)


def main() -> None:
    c = cfg()
    if role() == "exit":
        exit_rolling()
        return

    reset_day = int(c.get("IRAN_QUOTA_RESET_DAY") or 26)
    quota = int(c.get("IRAN_QUOTA_BYTES") or 1_500_000_000_000)
    used, source = vnstat_rx_since(reset_day)
    extra = [
        "فقط RX/دانلود شمرده شد؛ TX/آپلود در سهمیه نیست.",
        "تخمین محلی — پنل ارائه‌دهنده ایران API ندارد.",
        f"روز ریست (IRAN_QUOTA_RESET_DAY)={reset_day}",
    ]
    maybe_iran_reminder(c)
    if used is None:
        send("quota", "info", "نتوانستم مصرف ترافیک ایران را بخوانم", extra)
        return
    fire_iran_levels(int(used), quota, source, extra, reset_day)


if __name__ == "__main__":
    main()
