#!/bin/bash
set -euo pipefail
# shellcheck disable=SC1091
set -a; . /root/.vpn-secrets/.env; set +a
STAMP=$(date -u +%Y%m%dT%H%M%SZ)
DEST=/root/.pg_nodes/backups
mkdir -p "$DEST"
chmod 700 "$DEST"
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
# configs, not the live .env passwords file itself in plaintext if we encrypt the archive
cp -a /root/.pg_nodes/exit "$TMP/" 2>/dev/null || true
cp -a /root/.pg_nodes/iran "$TMP/" 2>/dev/null || true
cp -a /root/.pg_nodes/test-subs "$TMP/" 2>/dev/null || true
# panel db if present
if docker ps --format '{{.Names}}' | grep -qx pasarguard; then
  docker cp pasarguard:/code/db.sqlite3 "$TMP/pasarguard.sqlite3" 2>/dev/null || true
fi
if [ -d /opt/pasarguard ]; then
  cp -a /opt/pasarguard/.env "$TMP/pasarguard.env" 2>/dev/null || true
fi
set +e
tar -C "$TMP" --warning=no-file-changed -czf "$TMP/pg.tgz" .
tar_rc=$?
set -e
# GNU tar returns 1 if files changed during read
if [ "$tar_rc" -gt 1 ] || [ ! -s "$TMP/pg.tgz" ]; then
  echo "TAR_FAIL $tar_rc" >&2
  exit 1
fi
gpg --batch --yes --passphrase "$BACKUP_PASSPHRASE" --symmetric --cipher-algo AES256 \
  -o "$DEST/vpn-${STAMP}.tar.gz.gpg" "$TMP/pg.tgz"
chmod 600 "$DEST/vpn-${STAMP}.tar.gz.gpg"
# retain 7 days
find "$DEST" -name 'vpn-*.tar.gz.gpg' -mtime +7 -delete
echo "BACKUP_OK $STAMP"
