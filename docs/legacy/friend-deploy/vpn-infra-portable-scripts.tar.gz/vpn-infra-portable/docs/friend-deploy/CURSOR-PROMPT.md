# Cursor prompt — replicate this 2-hop VPN stack

**Give your friend two things:**

1. This entire prompt (paste into Cursor).
2. The archive `vpn-infra-portable-scripts.tar.gz` — extract it in the workspace (recommended: `/root/vpn-infra`).  
   **Yes: send the whole tarball.** It is the scripts/configs pack (no secrets, no live user lists). Without it, Cursor will rewrite vpn-path, sync, sni-watch, etc. from scratch and you will debug for days.

Also copy `docs/friend-deploy/*.md` if you have them (`SCRIPTS-INSTALL.md`, `IMPLEMENTATION-GUIDE.md`, `NODE-DISABLED.md`). They are already inside the tarball under `docs/`.

Operator: fill in IPs, domains, and Cloudflare token **locally** (`.env` mode 600). Never paste secrets into chat.

---

You are an infrastructure engineer. Implement **this exact 2-hop architecture** on two empty Ubuntu 22.04 servers. Do **not** build a single-server VPN. Do **not** rewrite the portable scripts — adapt IPs, domains, and systemd paths only.

## Fill in (operator)

- Iran relay public IPv4: `IRAN_IP`
- Exit (EU/DE) public IPv4: `EXIT_IP`
- Client-entry hostname(s): `ir.EXAMPLE`
- Panel hostname for Iranian saved URLs (port 2096 via Iran): `panel.EXAMPLE_IR`
- Panel hostname for Exit / Cloudflare 443: `panel.EXAMPLE_EXIT`
- Backhaul CF hostname: `cdn.EXAMPLE`
- Backhaul XHTTP hostname: `xhttp.EXAMPLE`
- Cloudflare API token: in `/root/.vpn-secrets/.env` only

Replace every `193.228.90.107`, `202.61.249.173`, `jetengine.ir`, `jahanynegar.ir` found in the portable pack.

## Mandatory architecture

```
Client in Iran
  → Iran relay: VLESS Reality TCP 443 + VLESS Vision TCP 2053
       (+ optional Hysteria2 UDP 443 inbound)
  → backhaul to Exit, priority:
       1) TO-AMS-CF     XHTTP via Cloudflare orange (cdn.*)
       2) TO-AMS-XHTTP  XHTTP direct (xhttp.*)
       3) TO-AMS-DIRECT VLESS+TLS TCP 9443 on Exit, nft allow Iran IP only
       4) TO-AMS-TUIC   listed last; UDP often dies on Iranian DC DPI
  → Exit: internet egress (optional WARP for Google)
```

Clients never connect to the Exit for VPN. Reality owns Iran `:443` — **do not put nginx on Iran 443**.

**PasarGuard panel** runs only on Exit, bound to `127.0.0.1:8000`. Exit nginx terminates TLS on `:2096`. Public Exit TCP `443` is **nginx stream `ssl_preread`** (no TLS terminate): SNI `panel.*` → `127.0.0.1:2096`; default → XHTTP on `127.0.0.1:10443`. Exit Xray must **not** listen on public 443.

Panel core JSON (`iran-xray`) is **not** the Exit backhaul Xray JSON. Do not point PasarGuard at the Exit Xray config or it will overwrite the tunnel.

### Panel Node row — hard rule

Create an Iran **Node** row (API typically `:62050`) but leave it **disabled**, `keep_alive=0`. **Do not Enable it** on day one. **Do not delete the row** (user inbound tags attach to it).

Why: PasarGuard’s native path is Exit `POST https://IRAN:62050/start` with a huge body (full core + all users). The node can return HTTP 200 while the panel HTTP client **times out reading the body**, retries, and enters **LockControl**. Live Iran Xray is docker `pasarguard/node` (`xray -c stdin:`). Disk `/root/.pg_nodes/iran/xray.json` is unused until `/start`.

Required control plane instead:

- Exit every ~10s: `iran_sync_export.py` builds Backend protobuf from panel sqlite; SCP to Iran `/var/lib/pg-node/sync/` if hash changed.
- Iran every ~10s: `iran_sync_apply.py` `POST https://127.0.0.1:62050/start` if hash changed **or** `:443`/`:2053` are down.
- Exit every ~30s: `iran_stats_ingest.py` SSH + `xray api statsquery` on Iran, write `used_traffic` / `online_at` into sqlite (disabled nodes are not polled by the panel).

Iran must **never** poll `https://panel:2096` on the Exit **public IP** for node sync (TLS completes, then DPI drops HTTP). Humans reach the panel from Iran via backhaul or the local SOCKS, not via raw Exit IP.

After the stack works, you **may** experiment with native Enable **only if** Exit can complete POST `/start` to Iran `:62050` repeatedly under the panel’s timeout. Until that test passes, keep SCP + local apply.

## Cloudflare and DNS

Zone: SSL **Full (Strict)**, **HTTP/3 off**.

| Record | Cloud | Points at | Role |
|---|---|---|---|
| `ir.*` | grey | Iran IP | Reality/Vision inbound. Never orange. |
| `panel.*` used as `:2096` sub URL | grey | Iran IP | Transparent panel proxy. Orange does not proxy 2096. |
| `panel.*` used as standard 443 | orange OK | Exit IP | Panel via CF + SNI mux |
| `cdn.*` / `xhttp.*` | orange | Exit IP | Backhaul only, not client VPN |

One Let’s Encrypt cert (DNS-01 Cloudflare) with SANs for all `panel.*` / `ir.*` / `cdn.*` / `xhttp.*`. Copy fullchain+key to Iran. Test Iranian DNS hijack: `dig @8.8.8.8` from the relay.

## Portable pack — do not rewrite

Extract `vpn-infra-portable-scripts.tar.gz`. Treat these as source of truth; only substitute IP/domain/repo path (`/root/vpn-infra`):

- `vpn-path`, `vpn-path-core.py`, `vpn_path_lib.py`, `vpn_paths.py`, `path_health.py`, `vpn_failover.py`
- `instagram-multiplier`, `instagram_multiplier.py`
- entire `scripts/sni-watch/`
- `iran_sync_export.py`, `iran_sync_apply.py`, `build_iran_start_proto.py`, `iran_stats_ingest.py`
- `cf_dns.py`, nginx iran-subproxy + `xray-subproxy.*`, nftables, monitor
- systemd units: `iran-sync-*`, `iran-stats-*`, `vpn-failover-*`

Do **not** blindly run `bootstrap-iran.sh` (it assumes systemd Xray; live Iran Xray is docker node).

Install per `docs/friend-deploy/SCRIPTS-INSTALL.md`:

1. **vpn-path** on Exit → `/usr/local/sbin/vpn-path` + `vpn-failover.timer`
2. **instagram-multiplier** on Exit → `/usr/local/sbin/instagram-multiplier` + `/etc/vpn-monitor/` (empty users file; do not copy another stack’s user ids). Useless without export/stats inject.
3. **sni-watch** UI at `https://panel…:2096/watch/` — service on Iran `127.0.0.1:8787`, SSH tunnel from Exit, nginx `location /watch/`. Needs Xray stdin wrap for SNI access log. Login is **not** PasarGuard.

Monitor: `scripts/monitor/install.sh exit` and `iran`. Drop NETCUP_* if the VPS is not netcup.

## Routing: panel from Iran

On Iran, **before** DIRECT `geosite:category-ir` / `*.ir`, send `panel.*` to balancer `backhaul`. On Exit, those hostnames go outbound `PANEL-LOCAL` → `127.0.0.1:2096`.

Iran admin SOCKS: `127.0.0.1:11080`, inbound tag `PANEL-ADMIN`, localhost-only, not assigned to panel users.

Transparent panel proxy on Iran: nginx `:2096` and `:8443`, `proxy_pass https://127.0.0.1:10444` (xray-subproxy → SOCKS → backhaul). Dokodemo destination must be a hostname whose DNS still points at **Exit** (otherwise hairpin after you move `panel.*` A to Iran). Proxy `location /` (not only `/dashboard/`) so `/statics/`, `/api/`, `/sub/` load. `proxy_ssl_verify off` on loopback. nft TCP 2096 open.

## Firewall minimum

Iran: TCP 22, 443, 2053, 8443, 2096; UDP 443; 62050/62051 **only from EXIT_IP**.

Exit: TCP 22, 80, 443, 2096 from world; TCP 9443 and backhaul UDP **only from IRAN_IP**; panel `:8000` not reachable from WAN.

## Nine steps (finish and test each)

1. Domains + Cloudflare + SAN cert  
2. Exit: nft, backhaul Xray, nginx stream 443 + http 2096  
3. Docker PasarGuard; iran-xray core; Node row disabled  
4. Iran: docker node, Reality 443, Vision 2053  
5. SSH keys; iran-sync-export/apply; iran-stats; **do not Enable node**  
6. Test CF then XHTTP then DIRECT; install vpn-path  
7. Iran nginx/xray-subproxy 2096; grey `panel.*` A to Iran if clients keep `:2096` URLs  
8. instagram-multiplier + sni-watch + monitor  
9. Real-client test (Reality **fragment tlshello** in the app), backups, lock down SSH  

Never print secrets. Do not git commit unless asked. Do not Enable the Iran node.

## Done when

Report (no secrets): final IPs/hostnames; node still disabled; `vpn-path status`; sub URL and dashboard HTTP 200 via Iran `:2096`; Reality still `xray` on Iran 443 not nginx; which backhaul tag is live; which portable files were installed unchanged vs which paths you substituted.
