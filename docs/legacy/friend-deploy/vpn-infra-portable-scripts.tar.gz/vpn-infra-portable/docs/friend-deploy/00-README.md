# بستهٔ انتقال استک دوهاب برای سرور جدید

این پوشه مال **شما** است (داکیومنت + پرامپت + اسکریپت). سکرت و لیست کاربر این استک داخلش نیست.

| فایل | برای کی |
|---|---|
| `CURSOR-PROMPT.md` | کپی کامل → دوست → چت Cursor روی سرورهای جدید |
| `IMPLEMENTATION-GUIDE.md` | داکیومنت خودتان؛ ۹ مرحله با جزئیات |
| `NODE-DISABLED.md` | چرا نود پنل خاموش است و کی می‌شود روشنش کرد |
| `SCRIPTS-INSTALL.md` | vpn-path، ضریب اینستا، دیده‌بان `/watch/`، بقیه |
| `vpn-infra-portable-scripts.tar.gz` | بریزید روی سیستم شخصی، بعد بدهید به Cursor دوست |

چاپ PDF: فایل `IMPLEMENTATION-GUIDE.html` را در Chrome/Edge باز کنید → Print → Save as PDF (wkhtmltopdf حروف فارسی را جدا می‌کند؛ از آن استفاده نکنید).

روی سیستم شخصی کل پوشه `docs/friend-deploy` به‌علاوه tar اسکریپت‌ها را کپی کنید.
